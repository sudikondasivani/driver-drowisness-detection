css_string = """
             <style>

            .sidebar {max-width:100%; float:right}
            .side-block img {width:100%}
            .side-block {margin-bottom:15px}
            .side-block a.button {margin-bottom:30px; background: #006CFF; color: #fff;font-weight: 500;font-size: 16px;line-height: 20px;padding: 15px;display: inline-block;max-width: 300px;border-radius: 5px; text-decoration:none;   }
            .side-block a.button:hover {background:#000}

            </style> 

            <div class="sidebar">

            <div class="side-block">
            <a target="_blank" href="https://opencv.org/courses" rel="noopener">
            <img src="https://learnopencv.com/wp-content/uploads/2022/03/opencv-course1.png" alt="Opencv Courses">
            </div>
            <div class="side-block">
            <a href="https://learnopencv.com" class="button ">Subscribe To My Newsletter</a>
            <div class="side-block">
            </div>
            <a target="_blank" href="https://pallet.xyz/list/ai-jobs?" rel="noopener">
            <img src="https://learnopencv.com/wp-content/uploads/2022/02/learnopencv-ai-jobs.jpg" alt="Opencv Courses">
            </div>
            <div class="side-block">
            <a target="_blank" href="https://bigvision.ai" rel="noopener">
            <img src="https://learnopencv.com/wp-content/uploads/2022/02/bigvision.jpg" alt="Opencv Courses"></a>
            </div>
            </div> 

            """
